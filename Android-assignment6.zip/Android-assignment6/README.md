# Software Studio Android Assignment 6

## Submission

The procedure of submission is as following:

1. Fork this repository on GitLab.
2. Clone the repository you forked.
3. Finish your work.
4. Commit your work, push to GitLab and then open a merge request to submit.

## Deadline

Sumbit your work before **2016/6/2 (Thu.) 23:59:59**.

Late submissions **WILL NOT** be accepted.

